## Isomorphic Redux Demo

Basic isomorphic app built on [Redux](https://github.com/gaearon/redux)

```
$ npm run dev
$ browser http://localhost:3000
```
