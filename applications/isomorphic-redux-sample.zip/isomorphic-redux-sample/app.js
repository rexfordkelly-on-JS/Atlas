'use strict';

require('babel-core/register')({});
require('babel-polyfill');

var server = require('./server').default;

module.exports = server;